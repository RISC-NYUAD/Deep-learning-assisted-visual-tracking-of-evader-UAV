This module provides the FHOG implementation from
http://vision.ucsd.edu/~pdollar/toolbox/doc/
with an OpenCV integration.
