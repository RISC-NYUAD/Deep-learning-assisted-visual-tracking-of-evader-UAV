//KMEANS
//https://github.com/marcoscastro/kmeans/blob/master/kmeans.cpp
class PointM
{
private:
	int id_point, id_cluster;
	vector<double> values;
	int total_values;
	string name;

public:
	PointM(int id_point, vector<double>& values, string name = "")
	{
		this->id_point = id_point;
		total_values = values.size();

		for(int i = 0; i < total_values; i++)
			this->values.push_back(values[i]);

		this->name = name;
		id_cluster = -1;
	}

	int getID()
	{
		return id_point;
	}

	void setCluster(int id_cluster)
	{
		this->id_cluster = id_cluster;
	}

	int getCluster()
	{
		return id_cluster;
	}

	double getValue(int index)
	{
		return values[index];
	}

	int getTotalValues()
	{
		return total_values;
	}

	void addValue(double value)
	{
		values.push_back(value);
	}

	string getName()
	{
		return name;
	}
};

class Cluster
{
private:
	int id_cluster;
	vector<double> central_values;
	vector<PointM> points;

public:
	Cluster(int id_cluster, PointM point)
	{
		this->id_cluster = id_cluster;

		int total_values = point.getTotalValues();

		for(int i = 0; i < total_values; i++)
			central_values.push_back(point.getValue(i));

		points.push_back(point);
	}

	void addPoint(PointM point)
	{
		points.push_back(point);
	}

	bool removePoint(int id_point)
	{
		int total_points = points.size();

		for(int i = 0; i < total_points; i++)
		{
			if(points[i].getID() == id_point)
			{
				points.erase(points.begin() + i);
				return true;
			}
		}
		return false;
	}

	double getCentralValue(int index)
	{
		return central_values[index];
	}

	void setCentralValue(int index, double value)
	{
		central_values[index] = value;
	}

	PointM getPoint(int index)
	{
		return points[index];
	}

	int getTotalPoints()
	{
		return points.size();
	}

	int getID()
	{
		return id_cluster;
	}
};

class KMeans
{
private:
	int K; // number of clusters
	int total_values, total_points, max_iterations;
	vector<Cluster> clusters;

	// return ID of nearest center (uses euclidean distance)
	int getIDNearestCenter(PointM point)
	{
		double sum = 0.0, min_dist;
		int id_cluster_center = 0;

		for(int i = 0; i < total_values; i++)
		{
			sum += pow(clusters[0].getCentralValue(i) -
					   point.getValue(i), 2.0);
		}

		min_dist = sqrt(sum);

		for(int i = 1; i < K; i++)
		{
			double dist;
			sum = 0.0;

			for(int j = 0; j < total_values; j++)
			{
				sum += pow(clusters[i].getCentralValue(j) -
						   point.getValue(j), 2.0);
			}

			dist = sqrt(sum);

			if(dist < min_dist)
			{
				min_dist = dist;
				id_cluster_center = i;
			}
		}

		return id_cluster_center;
	}

public:
	KMeans(int K, int total_points, int total_values, int max_iterations)
	{
		this->K = K;
		this->total_points = total_points;
		this->total_values = total_values;
		this->max_iterations = max_iterations;
	}

	vector<double> run(vector<PointM> & points, int maxPointCount, Mat flow, Mat cflow)//int run(vector<PointM> & points)//void run(vector<PointM> & points)
	{
		if(K > total_points){
			vector<double> returnValue;
			return returnValue;//return 0;
		}

		vector<int> prohibited_indexes;

		// choose K distinct values for the centers of the clusters
		for(int i = 0; i < K; i++)
		{
			while(true)
			{
				int index_point = rand() % total_points;

				if(find(prohibited_indexes.begin(), prohibited_indexes.end(),
						index_point) == prohibited_indexes.end())
				{
					prohibited_indexes.push_back(index_point);
					points[index_point].setCluster(i);
					Cluster cluster(i, points[index_point]);
					clusters.push_back(cluster);
					break;
				}
			}
		}

		int iter = 1;

		while(true)
		{
			bool done = true;

			// associates each point to the nearest center
			for(int i = 0; i < total_points; i++)
			{
				int id_old_cluster = points[i].getCluster();
				int id_nearest_center = getIDNearestCenter(points[i]);

				if(id_old_cluster != id_nearest_center)
				{
					if(id_old_cluster != -1)
						clusters[id_old_cluster].removePoint(points[i].getID());

					points[i].setCluster(id_nearest_center);
					clusters[id_nearest_center].addPoint(points[i]);
					done = false;
				}
			}

			// recalculating the center of each cluster
			for(int i = 0; i < K; i++)
			{
				for(int j = 0; j < total_values; j++)
				{
					int total_points_cluster = clusters[i].getTotalPoints();
					double sum = 0.0;

					if(total_points_cluster > 0)
					{
						for(int p = 0; p < total_points_cluster; p++)
							sum += clusters[i].getPoint(p).getValue(j);
						clusters[i].setCentralValue(j, sum / total_points_cluster);
					}
				}
			}

			if(done == true || iter >= max_iterations)
			{
				//cout << "Break in iteration " << iter << "\n\n";
				break;
			}

			iter++;
		}

		// shows elements of clusters
		if(1==0){
			for(int i = 0; i < K; i++)
			{
				int total_points_cluster =  clusters[i].getTotalPoints();

				cout << "Cluster " << clusters[i].getID() + 1 << endl;
				for(int j = 0; j < total_points_cluster; j++)
				{
					cout << "Point " << clusters[i].getPoint(j).getID() + 1 << ": ";
					for(int p = 0; p < total_values; p++)
						cout << clusters[i].getPoint(j).getValue(p) << " ";

					string point_name = clusters[i].getPoint(j).getName();

					if(point_name != "")
						cout << "- " << point_name;

					cout << endl;
				}

				cout << "Cluster values: ";

				for(int j = 0; j < total_values; j++)
					cout << clusters[i].getCentralValue(j) << " ";

				cout << "\n\n";
			}
		}


		//ASSUME 2 clusters for flow field
		if(1==0){
			int returnValue = 0;
		
			int total_points_clusterA = clusters[0].getTotalPoints();
			int total_points_clusterB = clusters[1].getTotalPoints();

			int smallestCluster = 0;
			if(total_points_clusterB < total_points_clusterA){
				smallestCluster = 1;		
			}
			int total_points_smallest_cluster = clusters[smallestCluster].getTotalPoints();

			if(total_points_smallest_cluster < 30)//define this dynamically based on step chosen to grab vectors from field
			{
				returnValue = clusters[smallestCluster].getPoint(0).getID(); //get one of the points, not need more if cluster members really close
			}
			//return returnValue;
		}

		if(K==2 || 1==1){
			vector<double> returnValue;

			int total_points_clusterA = clusters[0].getTotalPoints();
			int total_points_clusterB = clusters[1].getTotalPoints();

			int smallestCluster = 0;
			if(total_points_clusterB < total_points_clusterA){
				smallestCluster = 1;		
			}
			int total_points_smallest_cluster = clusters[smallestCluster].getTotalPoints();

			//check biggest cluster for uniformity, assume static background (backStatic = true) if below threshold
			int largestCluster = 0;
			if(smallestCluster==0){largestCluster = 1;}
			int total_points_largest_cluster = clusters[largestCluster].getTotalPoints();
			double sumX = 0;
			double sumY = 0;
			double sumDX = 0;
			double sumDY = 0;
			double count_pointsA = 0;
			//for(int i = 0; i < clusters[largestCluster].getTotalPoints(); i += 1){ //for(int i = 0; i < pointOfInterest.size(); i += 1){ 
				for(int y = 0; y < cflow.rows; y += 1){
					for(int x = 0; x < cflow.cols; x += 1)
					{
						//if(count_pointsA > 0 && count_pointsA == clusters[largestCluster].getPoint(i).getID()){
							const Point2f& fxy = flow.at<Point2f>(y, x);

							//sumX = sumX + abs(fxy.x);
							sumY = sumY + abs(fxy.y);
							sumX = sumX + sqrt(fxy.x * fxy.x + fxy.y * fxy.y);			
							sumDX = sumDX + fxy.x;
							sumDY = sumDY + fxy.y;

							//clusterCenterX = clusterCenterX + x + fxy.x;
							//clusterCenterY = clusterCenterY + y + fxy.y;
							//vX.push_back(x + fxy.x);
							//vY.push_back(y + fxy.y);		
							//circle(cflow, Point(cvRound(x+fxy.x), cvRound(y+fxy.y)), 5,  CV_RGB(255, 0, 0), -1);
						//}
						count_pointsA++;
					}			
				}
			//}
			//sumX = 100000 * sumX / (cflow.rows * cflow.cols);
			sumX = 1000 * sumX /  (cflow.rows * cflow.cols);//clusters[largestCluster].getTotalPoints();
			sumY = 100000 * sumY / (cflow.rows * cflow.cols);

			sumDX = sumDX  * 0.00005;
			sumDY = sumDY  * 0.00005;
			circle(cflow, Point(cvRound((cflow.cols/2)+0), cvRound((cflow.rows/2)+0)), 5,  CV_RGB(255, 0, 0), -1);
			line(cflow, Point(cvRound((cflow.cols/2)+0), cvRound((cflow.rows/2)+0)), 
			Point(cvRound((cflow.cols/2)+sumDX), cvRound((cflow.rows/2)+sumDY)), CV_RGB(255, 255, 0));
			circle(cflow, Point(cvRound((cflow.cols/2)+sumDX), cvRound((cflow.rows/2)+sumDY)), 5,  CV_RGB(255, 0, 0), -1);

			emulatedCameraDirectionX = sumDX;
			emulatedCameraDirectionY = sumDY;

			//cout << "sumX=" << sumX << endl;
			//cout << "sumX=" << sumX << " ,sumY = " << sumY << endl;
			//if(sumX < 0.05 && sumY < 0.05 && sumX >  0.0001 && sumY > 0.0001){
			if(sumX < 99){
				backStatic = true;
				//cout << "BACK STATIC, sumX=" << sumX << ", sumY=" << sumY << endl;			
			}else{
				backStatic = false;
    			}

			if(total_points_smallest_cluster < maxPointCount)//define this dynamically based on step chosen to grab vectors from field
			{
				//returnValue = clusters[smallestCluster].getPoint(0).getID(); //just get one of the points, not need more if cluster members really close
				int total_points_cluster =  clusters[smallestCluster].getTotalPoints();

				//cout << "Cluster " << clusters[smallestCluster].getID() + 1 << endl;
				for(int j = 0; j < total_points_cluster; j++)
				{
					//cout << "Point " << clusters[smallestCluster].getPoint(j).getID() + 1 << ": " << endl;
					returnValue.push_back(clusters[smallestCluster].getPoint(j).getID());

					//for(int p = 0; p < total_values; p++){
						//cout << clusters[smallestCluster].getPoint(j).getValue(p) << " ";
					//}

					//string point_name = clusters[smallestCluster].getPoint(j).getName();

					//if(point_name != ""){
					//	cout << "- " << point_name;
					//}

					//cout << endl;
				}

				//cout << "Cluster values: ";

				//for(int j = 0; j < total_values; j++){
				//	cout << clusters[smallestCluster].getCentralValue(j) << " ";	
				//	returnValue.push_back(clusters[smallestCluster].getCentralValue(j));				
				//}				

				//cout << "\n\n";
			}

			return returnValue;
		}

		
	}
};
//END KMEANS
